package com.sensorprocessor.errorhandling;

import java.util.logging.Logger;

public class ErrorHandling {
    private static final Logger logger = Logger.getLogger(ErrorHandling.class.getName());

   
    public static final String ERR001 = "ERR001: File not found";
    public static final String ERR002 = "ERR002: Invalid data format";
    public static final String ERR003 = "ERR003: Processing error";
    public static final String ERR004 = "ERR004: Thresholds not defined";

    public static void handleFileNotFoundError(String fileName) {
        logger.severe(ERR001 + " - " + fileName);
    }

    
    public static void handleInvalidColumnCountError(int lineNumber, String lineContent) {
        logger.severe(ERR002 + " - Line " + lineNumber + ": " + lineContent);
    }


    public static void handleProcessingError(String errorMessage) {
        logger.severe(ERR003 + " - " + errorMessage);
    }

   
    public static void handleThresholdNotDefined(String sensorType) {
        logger.severe(ERR004 + " - No thresholds defined for sensor type: " + sensorType);
    }
}
