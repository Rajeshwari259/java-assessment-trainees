package com.sensorprocessor.outlier;

import com.sensorprocessor.model.SensorData;
import com.sensorprocessor.model.Threshold;
import com.sensorprocessor.errorhandling.ErrorHandling;

import java.util.*;

public class OutlierDetection {
    
 
    public Map<String, List<SensorData>> detectOutliers(List<SensorData> sensorDataList, Map<String, Threshold> thresholds) {
        Map<String, List<SensorData>> outliers = new HashMap<>();

        for (SensorData data : sensorDataList) {
            Threshold threshold = thresholds.get(data.getSensorType());

            if (threshold == null) {
           
                ErrorHandling.handleThresholdNotDefined(data.getSensorType());
                continue; 
            }

           
            if (data.getValue() < threshold.getMinThreshold() || data.getValue() > threshold.getMaxThreshold()) {
                outliers.computeIfAbsent(data.getSensorType(), k -> new ArrayList<>()).add(data);
            }
        }
        return outliers;
    }

  
    public Map<String, Map<String, Double[]>> calculateMonthlyStats(List<SensorData> sensorDataList) {
        Map<String, Map<String, Double[]>> monthlyStats = new HashMap<>();

        for (SensorData data : sensorDataList) {
           
            monthlyStats.putIfAbsent(data.getSensorType(), new HashMap<>());
            Map<String, Double[]> stats = monthlyStats.get(data.getSensorType());

            stats.putIfAbsent(data.getMonth(), new Double[]{0.0, 0.0, Double.MIN_VALUE, Double.MAX_VALUE});

            Double[] currentStats = stats.get(data.getMonth());

            try {
              
                currentStats[0] += data.getValue();
                
                currentStats[1] += 1;
               
                currentStats[2] = Math.max(currentStats[2], data.getValue());
            
                currentStats[3] = Math.min(currentStats[3], data.getValue());
            } catch (Exception e) {
                
                ErrorHandling.handleProcessingError("Error calculating stats for sensor type: " + data.getSensorType() + ", Month: " + data.getMonth() + " - " + e.getMessage());
            }
        }

        return monthlyStats;
    }
}

