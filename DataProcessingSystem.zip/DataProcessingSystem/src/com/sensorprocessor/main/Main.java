package com.sensorprocessor.main;

import com.sensorprocessor.ingestion.DataIngestion;
import com.sensorprocessor.model.SensorData;
import com.sensorprocessor.model.Threshold;
import com.sensorprocessor.outlier.OutlierDetection;
import com.sensorprocessor.processing.ProcessingModule;
import com.sensorprocessor.reporting.ReportingModule;


import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

public class Main {
    private static final Logger logger = Logger.getLogger(Main.class.getName());

    public static void main(String[] args) {
        DataIngestion dataIngestion = new DataIngestion();
        OutlierDetection outlierDetection = new OutlierDetection();
        ProcessingModule processingModule = new ProcessingModule();
        ReportingModule reportingModule = new ReportingModule();

        try {
     
            List<SensorData> sensorDataList = dataIngestion.readSensorData("sensor_data.csv");
            System.out.println("Sensor data successfully read from 'sensor_data.csv'."); 

     
            Map<String, Threshold> thresholds = dataIngestion.readThresholds("thresholds.csv");
            System.out.println("Threshold data successfully read from 'thresholds.csv'.");  

            
            Map<String, List<SensorData>> outliers = outlierDetection.detectOutliers(sensorDataList, thresholds);
            System.out.println("Outliers detected successfully.");  

        
            Map<String, Map<String, Double[]>> monthlyStats = processingModule.calculateMonthlyStats(sensorDataList);
            System.out.println("Monthly statistics calculated successfully.");  

           
            reportingModule.generateMonthlyStatsReport(monthlyStats, "monthly_stats.csv");
            System.out.println("Monthly stats report successfully generated and saved as 'monthly_stats.csv'.");  

            reportingModule.generateOutliersReport(outliers, thresholds, "outliers.csv");
            System.out.println("Outliers report successfully generated and saved as 'outliers.csv'.");  

        } catch (IOException e) {
            logger.severe("Error in processing the sensor data files: " + e.getMessage());
        }
    }
}
