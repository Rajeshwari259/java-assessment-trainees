package com.sensorprocessor.processing;

import com.sensorprocessor.model.SensorData;
import java.util.Map;
import java.util.HashMap;
import java.util.List;

public class ProcessingModule {

   
    public Map<String, Map<String, Double[]>> calculateMonthlyStats(List<SensorData> sensorDataList) {
        Map<String, Map<String, Double[]>> monthlyStats = new HashMap<>();

        for (SensorData data : sensorDataList) {
            
            monthlyStats.putIfAbsent(data.getSensorType(), new HashMap<>());
            Map<String, Double[]> stats = monthlyStats.get(data.getSensorType());

            stats.putIfAbsent(data.getMonth(), new Double[]{0.0, 0.0, Double.MIN_VALUE, Double.MAX_VALUE});  

            Double[] currentStats = stats.get(data.getMonth());
            currentStats[0] += data.getValue(); 
            currentStats[1] += 1; 
            currentStats[2] = Math.max(currentStats[2], data.getValue());
            currentStats[3] = Math.min(currentStats[3], data.getValue()); 
        }

        return monthlyStats;
    }
}
